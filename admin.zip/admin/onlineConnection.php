<?php
error_reporting(0);
$conn=mysqli_connect("node1","dineshka_nubh","1234@DkkarTik","dineshka_nubh");

if ($conn==false)
{
    die("Error :Not connect with  database");
}
else{
    // echo 'connected \/';
}
?>