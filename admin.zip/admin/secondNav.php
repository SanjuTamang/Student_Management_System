<?php include 'connection.php'?>
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title></title>
   <link rel="stylesheet" href="./css/index.css">
   <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
</head>
<body>
  <div class="bothnavbar">
      <div class="topNav">
        <div class="topSubNavbar topNavbarLeft">

        </div>
        <div class="topSubNavbar topNavbarReft">
          <img src="./images/user.png" alt="">
        <i class='far fa-comment-alt' style='font-size:24px'></i>
        <i class='fas fa-bell' style='font-size:24px'></i>
        </div>
<p>hi</p>
      </div>
      <div class="sidenav">
        <a href="#about">>About</a>
        <a href="#services">>Services</a>
        <a href="#clients">>Clients</a>
        <a href="#contact">>Contact</a>
      </div>
</div>
</body>
</html>