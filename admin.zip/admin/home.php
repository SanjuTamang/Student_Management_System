<?php
include 'navbar.php';

?>
<!DOCTYPE html>
 <html lang="en">
 <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="../admin/css/home.css">
<title>Admin Panel | full access </title>
</head>

<body>
  <div class="homeMainContainer">
     <div class="first">
        <div class="firstSubBoxFirst">
           <h2>Students</h2>
           <h3>345678</h3>
        </div>
        <div class="secondSubBoxFirst">
        <h2>Teachers</h2>
           <h3>345678</h3>
        </div>
        <div class="thirdSubBoxFirst">
        <h2>Parents</h2>
           <h3>345678</h3>
        </div>
        <div class="fourSubBoxFirst">
        <h2>Earning</h2>
           <h3>345678</h3>
        </div>
     </div>
     <div class="second">
        <div class="firstSubBoxSecond">

         </div>
        <div class="secondSubBoxSecond">

         </div>
        <div class="thirdSubBoxSecond">

         </div>

     </div>
  </div>
</body>
</html> 