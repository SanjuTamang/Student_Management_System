<?php
    include 'navbar.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="stylesheet" href="./css/studentIndex.css">
   <title>Teacher Home Page</title>
</head>
<body>
   <div class="mainIndex">
      <div class="firstSubBox">
         <div class="firstCommon firtstInside">
           <div class="firstInsideFirst firstFirstCommon">
            <p>Total Student</p>
            <p>4578</p>
           </div>
           <div class="firstInsideSecond firstFirstCommon">
            <p>Total Student</p>
            <p>4578</p>

           </div>
           <div class="firstInsideThird firstFirstCommon">
            <p>Total Student</p>
            <p>4578</p>

           </div>
           <div class="firstInsideForth firstFirstCommon">
            <p>Total Student</p>
            <p>4578</p>

           </div>
         </div>
         <div class="firstCommon secondInside">
            <h4>hello 2</h4>
         </div>
         <div class="firstCommon thirdInside">
            <h4>hello 3</h4>
         </div>
      </div>
      <div class="secondSubBox">
        <table>
           <thead>
              <tr>
                 <th>S No.</th>
                 <th>Teacher id</th>
                 <th>Name</th>
                 <th>Branch</th>
                 <th>Subject</th>
                 <th>Father Name</th>
                 <th>Mobile</th>
                 <th>E-mail</th>
                 <th>Address</th>
              </tr>
           </thead>
           <tbody>
              <tr>
                 <th>1</th>
                 <th>Bca1255</th>
                 <th>kartik</th>
                 <th>BCA</th>
                 <th>Math</th>
                 <th>k k prasad</th>
                 <th>90786790</th>
                 <th>adsad@fgdg</th>
                 <th>34,56</th>
              </tr>
              <tr>
                 <th>2</th>
                 <th>Bca1255</th>
                 <th>kartik</th>
                 <th>BCA</th>
                 <th>Math</th>
                 <th>k k prasad</th>
                 <th>90786790</th>
                 <th>adsad@fgdg</th>
                 <th>34,56 sheikhpura Bihar 81105</th>
              </tr>
              <tr>
                <th>3</th>
                 <th>Bca1255</th>
                 <th>kartik</th>
                 <th>BCA</th>
                 <th>Math</th>
                 <th>k k prasad</th>
                 <th>90786790</th>
                 <th>adsad@fgdg</th>
                 <th>34,56</th>
              </tr>
              <tr>
                 <th>14</th>
                 <th>kartik</th>
                 <th>BCA</th>
                 <th>Math</th>
                 <th>k k prasad</th>
                 <th>90786790</th>
                 <th>adsad@fgdg</th>
                 <th>34,56</th>
              </tr>
              <tr>
                 <th>14</th>
                 <th>kartik</th>
                 <th>BCA</th>
                 <th>Math</th>
                 <th>k k prasad</th>
                 <th>90786790</th>
                 <th>adsad@fgdg</th>
                 <th>34,56</th>
              </tr>
              <tr>
                 <th>14</th>
                 <th>kartik</th>
                 <th>BCA</th>
                 <th>Math</th>
                 <th>k k prasad</th>
                 <th>90786790</th>
                 <th>adsad@fgdg</th>
                 <th>34,56</th>
              </tr>
              <tr>
                 <th>14</th>
                 <th>kartik</th>
                 <th>BCA</th>
                 <th>Math</th>
                 <th>k k prasad</th>
                 <th>90786790</th>
                 <th>adsad@fgdg</th>
                 <th>34,56</th>
              </tr>
              <tr>
                 <th>14</th>
                 <th>kartik</th>
                 <th>BCA</th>
                 <th>Math</th>
                 <th>k k prasad</th>
                 <th>90786790</th>
                 <th>adsad@fgdg</th>
                 <th>34,56</th>
              </tr>
              <tr>
                 <th>14</th>
                 <th>kartik</th>
                 <th>BCA</th>
                 <th>Math</th>
                 <th>k k prasad</th>
                 <th>90786790</th>
                 <th>adsad@fgdg</th>
                 <th>34,56</th>
              </tr>
              <tr>
                 <th>14</th>
                 <th>kartik</th>
                 <th>BCA</th>
                 <th>Math</th>
                 <th>k k prasad</th>
                 <th>90786790</th>
                 <th>adsad@fgdg</th>
                 <th>34,56</th>
              </tr>
           </tbody>

        </table>
      </div>
      <div class="thirdSubBox">

      </div>
   </div>
</body>
</html>
      </div>
      <div class="secondSubBox secondFirst">
         <div class="serarchBox">
            <input type="search" name="search" id="sSearch" placeholder="search by roll no."> <button type="submit">search</button>
            <!-- <input type="search" name="search" id="sSearch" placeholder="search by Name" >
            <button type="submit">search</button>
            <input type="search" name="search" id="sSearch" placeholder="Search by phone">
            <button type="submit">search</button> -->