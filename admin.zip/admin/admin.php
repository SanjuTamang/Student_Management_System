<!DOCTYPE html>
<html lang="en">

<head>
<?php  
include 'navbar.php';
include 'allhead.php';
require 'connection.php';
?>